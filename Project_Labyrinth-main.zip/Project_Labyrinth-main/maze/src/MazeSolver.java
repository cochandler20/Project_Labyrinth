package maze;

import edu.princeton.cs.algs4.BreadthFirstPaths;
import edu.princeton.cs.algs4.Graph;

import java.util.ArrayList;
import java.util.List;

/**
 * Class 3: MazeSolver Finds the shortest path using BreadthFirstPaths.
 */
class MazeSolver {

    public static List<Integer> findShortestPath(Graph mazeGraph, int startVertex, int endVertex) {
        BreadthFirstPaths bfs = new BreadthFirstPaths(mazeGraph, startVertex);
        List<Integer> pathList = new ArrayList<>();

        if (bfs.hasPathTo(endVertex)) {
            // Convert Iterable<Integer> to a List for easy comparison.
            // The iterator for pathTo() returns the path from start to end.
            for (int v : bfs.pathTo(endVertex)) {
                pathList.add(v);
            }
            return pathList;
        }
        else {
            return null; // Should not happen in a perfect maze
        }
    }
}

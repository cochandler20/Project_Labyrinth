package maze;

import edu.princeton.cs.algs4.Graph;
import edu.princeton.cs.algs4.Stack;
import edu.princeton.cs.algs4.StdRandom;

import java.util.Random;

/**
 * Class 2: MazeGenerator Generates a perfect N-by-N maze using randomized Depth-First
 * Search, and then makes it imperfect by removing extra walls.
 */
class MazeGenerator {
    private final int N;
    private boolean[][] north, east, south, west;
    private final boolean[] visited;
    private final Graph mazeGraph;

    public MazeGenerator(int N) {
        this.N = N;
        this.visited = new boolean[N * N];
        this.mazeGraph = new Graph(N * N);

        north = new boolean[N][N];
        east = new boolean[N][N];
        south = new boolean[N][N];
        west = new boolean[N][N];
        for (int i = 0; i < N; i++) {
            for (int j = 0; j < N; j++) {
                north[i][j] = true;
                east[i][j] = true;
                south[i][j] = true;
                west[i][j] = true;
            }
        }

        // Seed for randomized generation
        StdRandom.setSeed(new Random().nextLong());
        generate(0);

        // Make the maze imperfect by knocking down a few more walls
        makeImperfect(N / 2);
    }

    // Randomized Depth-First Search (DFS) using an explicit stack
    private void generate(int startVertex) {
        Stack<Integer> stack = new Stack<>();
        stack.push(startVertex);
        visited[startVertex] = true;

        while (!stack.isEmpty()) {
            int v = stack.peek();

            int[] neighbors = getUnvisitedNeighbors(v);

            if (neighbors.length > 0) {
                int w = neighbors[StdRandom.uniformInt(neighbors.length)];

                removeWall(v, w);
                mazeGraph.addEdge(v, w);

                visited[w] = true;
                stack.push(w);
            }
            else {
                stack.pop();
            }
        }
    }

    /**
     * Randomly removes a specified number of internal walls to create loops.
     * @param wallsToKnock The number of walls to remove.
     */
    private void makeImperfect(int wallsToKnock) {
        int wallsKnocked = 0;
        while (wallsKnocked < wallsToKnock) {
            int row = StdRandom.uniformInt(N);
            int col = StdRandom.uniformInt(N);

            // true for horizontal wall (south), false for vertical (east)
            boolean horizontal = StdRandom.uniformInt(2) == 0;

            if (horizontal && row < N - 1) { // Try to knock a south wall
                if (south[row][col]) {
                    int v = row * N + col;
                    int w = (row + 1) * N + col;
                    removeWall(v, w);
                    mazeGraph.addEdge(v, w);
                    wallsKnocked++;
                }
            } else if (!horizontal && col < N - 1) { // Try to knock an east wall
                if (east[row][col]) {
                    int v = row * N + col;
                    int w = row * N + (col + 1);
                    removeWall(v, w);
                    mazeGraph.addEdge(v, w);
                    wallsKnocked++;
                }
            }
        }
    }

    // Helper to get all unvisited neighbors of a vertex v
    private int[] getUnvisitedNeighbors(int v) {
        int x = v % N;
        int y = v / N;

        edu.princeton.cs.algs4.Queue<Integer> neighbors = new edu.princeton.cs.algs4.Queue<>();

        // Check Down (y+1, vertex v+N)
        if (y < N - 1 && !visited[v + N]) {
            neighbors.enqueue(v + N);
        }
        // Check East (x+1, vertex v+1)
        if (x < N - 1 && !visited[v + 1]) {
            neighbors.enqueue(v + 1);
        }
        // Check Up (y-1, vertex v-N)
        if (y > 0 && !visited[v - N]) {
            neighbors.enqueue(v - N);
        }
        // Check West (x-1, vertex v-1)
        if (x > 0 && !visited[v - 1]) {
            neighbors.enqueue(v - 1);
        }

        int[] result = new int[neighbors.size()];
        int i = 0;
        for (int n : neighbors) {
            result[i++] = n;
        }
        return result;
    }

    /**
     * Helper to "knock down" the wall between two adjacent vertices v and w.
     */
    private void removeWall(int v, int w) {
        int x1 = v % N; // Col of v
        int y1 = v / N; // Row of v
        int x2 = w % N; // Col of w
        int y2 = w / N; // Row of w

        if (y1 < y2) {
            // v is above w. The connecting wall is SOUTH of v and NORTH of w.
            south[y1][x1] = false;
            north[y2][x2] = false;
        }
        else if (y1 > y2) {
            // v is below w. The connecting wall is NORTH of v and SOUTH of w.
            north[y1][x1] = false;
            south[y2][x2] = false;
        }
        else if (x1 < x2) { // w is East of v
            east[y1][x1] = false;
            west[y2][x2] = false;
        }
        else if (x1 > x2) { // w is West of v
            west[y1][x1] = false;
            east[y2][x2] = false;
        }
    }

    public Graph getGraph() {
        return mazeGraph;
    }

    public boolean[][] getNorthWalls() {
        return north;
    }

    public boolean[][] getEastWalls() {
        return east;
    }

    public boolean[][] getSouthWalls() {
        return south;
    }

    public boolean[][] getWestWalls() {
        return west;
    }
}

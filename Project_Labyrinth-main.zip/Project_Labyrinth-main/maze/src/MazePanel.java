package maze;

import edu.princeton.cs.algs4.Graph;
import edu.princeton.cs.algs4.StdAudio;
import edu.princeton.cs.algs4.StdRandom;

import javax.swing.*;
import java.awt.*;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import java.util.List;

/**
 * Class 4: MazePanel Extends JPanel to handle all Swing drawing, player state, and
 * keyboard input.
 */
class MazePanel extends JPanel {
    private enum GameState {
        PLAYING, WON_PERFECT, WON_SLOW, LOST
    }

    private final String step = ".//rsc//step.mid";
    private final int N;
    private final int FRAME_SIZE;
    private final int CELL_SIZE;
    private final int MARGIN = 10;
    private final int INSTRUCTION_OFFSET = 30; // Space for instructions at the top

    // Maze Structure (now mutable for regeneration)
    private Graph mazeGraph;
    private boolean[][] north, east, south, west;

    // Game State (now mutable for regeneration)
    private int startVertex;
    private int endVertex;
    private List<Integer> shortestPathList;

    private int playerVertex;
    private final List<Integer> playerPath; // Tracks player's movement history
    private GameState gameState;
    private int enemyVertex;
    private javax.swing.Timer enemyTimer;
    private static final int ENEMY_MOVE_DELAY_MS = 800; // Enemy moves every 400ms
    private String instructions;

    public MazePanel(int N, int frameSize) {
        this.N = N;
        this.FRAME_SIZE = frameSize;

        int drawingArea = FRAME_SIZE - 2 * MARGIN;
        this.CELL_SIZE = drawingArea / N;

        setPreferredSize(new Dimension(FRAME_SIZE, FRAME_SIZE + INSTRUCTION_OFFSET + MARGIN));
        setBackground(new Color(240, 240, 245)); // Light bluish-gray background

        this.playerPath = new ArrayList<>();

        // Set up a timer to move the enemy
        enemyTimer = new javax.swing.Timer(ENEMY_MOVE_DELAY_MS, e -> moveEnemy());

        generateNewMaze(); // Initial maze generation

        setupKeyListener();
        setupMouseListener();
    }

    /**
     * Generates a completely new maze, start point, end point, and shortest path.
     */
    private void generateNewMaze() {
        // 1. Generate new Maze structure
        MazeGenerator generator = new MazeGenerator(N);
        this.mazeGraph = generator.getGraph();
        this.north = generator.getNorthWalls();
        this.east = generator.getEastWalls();
        this.south = generator.getSouthWalls();
        this.west = generator.getWestWalls();

        // 2. Set new Start/End Points (Start: Row 0, End: Row N-1)
        this.startVertex = StdRandom.uniform(N); // Random col, row 0
        this.endVertex = (N - 1) * N + StdRandom.uniform(N); // Random col, row N-1

        // 3. Calculate new shortest path
        this.shortestPathList = MazeSolver.findShortestPath(mazeGraph, startVertex, endVertex);

        // 4. Reset player state for the new maze
        this.playerVertex = startVertex;
        this.playerPath.clear();
        playerPath.add(startVertex);
        this.gameState = GameState.PLAYING;
        this.instructions = "Use ARROW KEYS to reach the green EXIT. Match the shortest path length!";

        // 5. Reset enemy state
        // Start enemy at a random column in the last row, different from the exit
        do {
            this.enemyVertex = (N - 1) * N + StdRandom.uniform(N);
        } while (enemyVertex == endVertex);
        enemyTimer.stop(); // Stop any previous timer
        enemyTimer.start(); // Start the enemy movement
    }

    private void setupKeyListener() {
        addKeyListener(new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent e) {
                if (gameState == GameState.PLAYING) {
                    handlePlayerMove(e.getKeyCode()); // This might change gameState
                }
                else if (e.getKeyCode() == KeyEvent.VK_SPACE) {
                    // Spacebar to reset
                    resetGame();
                }
            }
        });
    }

    private void setupMouseListener() {
        addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                if (gameState != GameState.PLAYING) {
                    resetGame();
                }
            }
        });
    }

    private void resetGame() {
        // Now resets the entire game state, including generating a new maze
        generateNewMaze();
        repaint();
    }

    // --- Game Logic ---

    private void handlePlayerMove(int keyCode) {
        int oldRow = playerVertex / N;
        int oldCol = playerVertex % N;
        int newVertex = playerVertex;
        boolean moved = false;

        switch (keyCode) {
            case KeyEvent.VK_UP:
                // Check North wall
                if (oldRow > 0 && !north[oldRow][oldCol]) {
                    newVertex = playerVertex - N;
                    moved = true;
                }
                break;
            case KeyEvent.VK_DOWN:
                // Check South wall
                if (oldRow < N - 1 && !south[oldRow][oldCol]) {
                    newVertex = playerVertex + N;
                    moved = true;
                }
                break;
            case KeyEvent.VK_LEFT:
                // Check West wall
                if (oldCol > 0 && !west[oldRow][oldCol]) {
                    newVertex = playerVertex - 1;
                    moved = true;
                }
                break;
            case KeyEvent.VK_RIGHT:
                // Check East wall
                if (oldCol < N - 1 && !east[oldRow][oldCol]) {
                    newVertex = playerVertex + 1;
                    moved = true;
                }
                break;
        }

        if (moved) {
        	StdAudio.playInBackground(".//rsc//move.mid");
            // Update position and path
            playerVertex = newVertex;

            // Handle player path history: if backtracking, remove last step
            if (playerPath.size() > 1 && playerPath.get(playerPath.size() - 2) == newVertex) {
                playerPath.remove(playerPath.size() - 1);
            }
            else if (playerPath.get(playerPath.size() - 1) != newVertex) {
                // Only add if it's a new, non-backtracking move
                playerPath.add(newVertex);
            }

            checkWinCondition();
            repaint();
        }
    }

    private void moveEnemy() {
        if (gameState != GameState.PLAYING) {
            enemyTimer.stop();
            
            return;
        }

        // Use the existing MazeSolver to find the path from the enemy to the player
        List<Integer> pathToPlayer = MazeSolver.findShortestPath(mazeGraph, enemyVertex, playerVertex);
        StdAudio.playInBackground(step);
        // If a path exists and the enemy is not already on the player
        if (pathToPlayer != null && pathToPlayer.size() > 1) {
            // The next step for the enemy is the second vertex in the path list
            // (the first is the enemy's current location)
            enemyVertex = pathToPlayer.get(1);
        }

        
        checkLossCondition();
        repaint();
    }

    private void checkLossCondition() {
        if (playerVertex == enemyVertex) {
            gameState = GameState.LOST;
            instructions = "YOU WERE CAUGHT! Click or press SPACE to try again.";
            enemyTimer.stop();
        }
    }

    @Override
    protected void processKeyEvent(KeyEvent e) {
        // Override to ensure player move and loss check happen before enemy move
        if (e.getID() == KeyEvent.KEY_PRESSED) {
            super.processKeyEvent(e); // This will call the KeyListener's keyPressed
            checkLossCondition(); // Check for loss immediately after player moves
        }
    }

    private void checkWinCondition() {
        if (playerVertex == endVertex) {
            int playerSteps = playerPath.size() - 1; // Subtract 1 because path includes start point
            int shortestSteps = shortestPathList.size() - 1;

            if (playerSteps == shortestSteps) {
                gameState = GameState.WON_PERFECT;
                
                StdAudio.playInBackground(".//rsc//win_perfect.mid");
                instructions = String.format("PERFECT WIN! %d steps (Shortest Path). Click or press SPACE to play a new maze.", shortestSteps);
            }
            else {
                gameState = GameState.WON_SLOW;
                StdAudio.playInBackground(".//rsc//win.mid");
                instructions = String.format("You Win, but slow! %d steps (Shortest: %d). Click or press SPACE to play a new maze.", playerSteps, shortestSteps);
            }
            enemyTimer.stop(); // Stop the enemy when the player wins
        }
    }

    // --- Drawing Logic ---

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2d = (Graphics2D) g;
        g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

        drawInstructions(g2d);
        drawMaze(g2d);

        // Draw the path lines for comparison only if the game is over
        if (gameState == GameState.WON_PERFECT || gameState == GameState.WON_SLOW || gameState == GameState.LOST) {
            drawSolutionPath(g2d, shortestPathList, new Color(100, 255, 100, 100)); // Shortest Path (Light Green)
            drawSolutionPath(g2d, playerPath, new Color(255, 100, 100, 180)); // Player Path (Semi-transparent Red)
        }

        drawStartEndPoints(g2d);
        drawEnemy(g2d);
        drawPlayer(g2d);

        // Draw "You Lose" overlay if the player was caught
        if (gameState == GameState.LOST) {
            g2d.setColor(new Color(150, 0, 0, 128)); // Semi-transparent dark red
            g2d.fillRect(0, 0, getWidth(), getHeight());

            g2d.setFont(new Font("Arial", Font.BOLD, 50));
            g2d.setColor(Color.WHITE);
            String msg = "YOU LOSE";
            FontMetrics fm = g2d.getFontMetrics();
            int msgWidth = fm.stringWidth(msg);
            g2d.drawString(msg, (getWidth() - msgWidth) / 2, getHeight() / 2);
            StdAudio.playInBackground(".//rsc//lose.mid");
        }
    }

    private void drawInstructions(Graphics2D g2d) {
        g2d.setColor(Color.DARK_GRAY);
        g2d.fillRect(0, 0, FRAME_SIZE, MARGIN + INSTRUCTION_OFFSET);
        g2d.setColor(Color.WHITE);
        g2d.setFont(new Font("Arial", Font.BOLD, 14));
        FontMetrics fm = g2d.getFontMetrics();
        int x = (FRAME_SIZE - fm.stringWidth(instructions)) / 2;
        int y = MARGIN + INSTRUCTION_OFFSET / 2 + fm.getAscent() / 2;
        g2d.drawString(instructions, x, y);
    }

    private void drawMaze(Graphics2D g2d) {
        g2d.setColor(Color.BLACK);
        g2d.setStroke(new BasicStroke(2.0f));

        for (int row = 0; row < N; row++) {
            for (int col = 0; col < N; col++) {
                int x = col * CELL_SIZE + MARGIN;
                int y = row * CELL_SIZE + MARGIN + INSTRUCTION_OFFSET;

                // Draw walls based on the generator's wall arrays
                if (north[row][col]) {
                    g2d.drawLine(x, y, x + CELL_SIZE, y);
                }
                if (east[row][col]) {
                    g2d.drawLine(x + CELL_SIZE, y, x + CELL_SIZE, y + CELL_SIZE);
                }
                if (south[row][col]) {
                    g2d.drawLine(x, y + CELL_SIZE, x + CELL_SIZE, y + CELL_SIZE);
                }
                if (west[row][col]) {
                    g2d.drawLine(x, y, x, y + CELL_SIZE);
                }
            }
        }

        // Outer boundary
        g2d.setStroke(new BasicStroke(3.0f));
        int mazeTopY = MARGIN + INSTRUCTION_OFFSET;
        int mazeBottomY = mazeTopY + N * CELL_SIZE;
        int mazeLeftX = MARGIN;
        int mazeRightX = MARGIN + N * CELL_SIZE;

        g2d.drawLine(mazeLeftX, mazeTopY, mazeRightX, mazeTopY);
        g2d.drawLine(mazeLeftX, mazeBottomY, mazeRightX, mazeBottomY);
        g2d.drawLine(mazeLeftX, mazeTopY, mazeLeftX, mazeBottomY);
        g2d.drawLine(mazeRightX, mazeTopY, mazeRightX, mazeBottomY);
    }

    private void drawSolutionPath(Graphics2D g2d, List<Integer> path, Color color) {
        if (path == null) {
            return;
        }

        g2d.setColor(color);

        for (int v : path) {
            int row = v / N;
            int col = v % N;
            int x = col * CELL_SIZE + MARGIN;
            int y = row * CELL_SIZE + MARGIN + INSTRUCTION_OFFSET;

            // Fill the cell for the path
            g2d.fillRect(x + 1, y + 1, CELL_SIZE - 1, CELL_SIZE - 1);
        }
    }

    private void drawStartEndPoints(Graphics2D g2d) {
        drawVertex(g2d, startVertex, Color.BLUE, CELL_SIZE / 3);
        drawVertex(g2d, endVertex, Color.GREEN.darker(), CELL_SIZE / 3);
    }

    private void drawEnemy(Graphics2D g2d) {
        drawVertex(g2d, enemyVertex, Color.MAGENTA.darker(), CELL_SIZE / 2);
    }

    private void drawPlayer(Graphics2D g2d) {
        drawVertex(g2d, playerVertex, Color.ORANGE, CELL_SIZE / 2);
    }

    private void drawVertex(Graphics2D g2d, int v, Color color, int size) {
        int row = v / N;
        int col = v % N;
        int x = col * CELL_SIZE + MARGIN;
        int y = row * CELL_SIZE + MARGIN + INSTRUCTION_OFFSET;

        g2d.setColor(color);
        // Draw a circle in the center of the cell
        g2d.fillOval(x + CELL_SIZE / 2 - size / 2,
                y + CELL_SIZE / 2 - size / 2,
                size, size);
    }
}

package maze;

import javax.swing.*;

/**
 * Main Maze class.
 * This class sets up the main Java Swing window (JFrame) and initializes the game components.
 */
public class Maze {

    private static final int N = 20; // Maze size (N-by-N)
    private static final int FRAME_SIZE = 700; // Window size in pixels

    // The main entry point for the application
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            JFrame frame = new JFrame("Perfect Maze Game (Shortest Path Challenge)");
            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

            // The MazePanel is now responsible for generating the maze internally on init and reset.
            MazePanel mazePanel = new MazePanel(N, FRAME_SIZE);

            frame.add(mazePanel);
            frame.pack(); // Adjust frame size to fit components
            frame.setLocationRelativeTo(null); // Center the window
            frame.setVisible(true);

            // Crucial for KeyListener: ensure the panel has focus
            mazePanel.setFocusable(true);
            mazePanel.requestFocusInWindow();
        });
    }
}


